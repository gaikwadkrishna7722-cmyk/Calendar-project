// Number of days to show (like GitHub: last 365 days)
const DAYS_TO_SHOW = 365;

const calendarEl = document.getElementById("calendar");

// helper: get dates from today backwards
function getLastNDates(n) {
    const dates = [];
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    for (let i = 0; i < n; i++) {
        const d = new Date(today);
        d.setDate(today.getDate() - i);
        dates.push(d);
    }
    return dates.reverse(); // oldest first
}

// fake contribution count (you can replace with real data later)
function getFakeContributionCount() {
    // 0 to 10
    return Math.floor(Math.random() * 11);
}

function getLevelFromCount(count) {
    if (count === 0) return 0;
    if (count <= 2) return 1;
    if (count <= 4) return 2;
    if (count <= 7) return 3;
    return 4;
}

function buildCalendar() {
    const dates = getLastNDates(DAYS_TO_SHOW);

    // group dates into weeks (each column)
    const weeks = [];
    let currentWeek = [];

    // align so columns start at Sunday like GitHub
    const firstDay = dates[0].getDay(); // 0=Sun
    for (let i = 0; i < firstDay; i++) {
        currentWeek.push(null); // empty cells at top
    }

    dates.forEach(date => {
        currentWeek.push(date);
        if (currentWeek.length === 7) {
            weeks.push(currentWeek);
            currentWeek = [];
        }
    });

    if (currentWeek.length > 0) {
        while (currentWeek.length < 7) {
            currentWeek.push(null);
        }
        weeks.push(currentWeek);
    }

    // render
    weeks.forEach(week => {
        const weekEl = document.createElement("div");
        weekEl.className = "week";

        week.forEach(day => {
            const dayEl = document.createElement("div");
            dayEl.classList.add("day");

            if (day) {
                const count = getFakeContributionCount();
                const level = getLevelFromCount(count);
                dayEl.classList.add(`level-${level}`);
                dayEl.title = `${count} contributions on ${day.toDateString()}`;
            } else {
                dayEl.classList.add("level-0");
            }

            weekEl.appendChild(dayEl);
        });

        calendarEl.appendChild(weekEl);
    });
}

buildCalendar();
